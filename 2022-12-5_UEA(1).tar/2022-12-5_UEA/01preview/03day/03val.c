/*================================================================
面试题
1.sizeof是不是一个函数?sizeof不是一个函数,sizeof是一个运算符
------------------------------------------------------------------
变量
1.变量的含义
	变量就是用来存储数据的(数据会存储到内存中<在内存中存储的都是二进制补码>)
2.变量的定义
	数据类型	变量名	;

	1)数据类型可以分为基本数据类型和复合型数据类型
	2)C语言中基本的数据类型
				signed/unsigned
		整型	有符号/无符号	short(短整型) int(整型) long(长整型)
		实型	有符号			float(单精度浮点类型) double(双精度浮点类型)
		字符型	有符号/无符号	char(字符型)
		有符号(signed)的数据类型既可以存储正数也可以存储负数
		无符号(unsigned)的数据类型只存储0 ~ 正整数
	3)使用sizeof运算符测试数据类型所占内存空间的大小
		使用方法 : sizeof(变量名/数据类型) -> 将来会计算出结果,结果是以字节为单位
		*******************************************
		小知识 : 
			字节用byte表示,位用bit表示
			1个字节 = 8个位
			1个字 = 2/4个字节
		*******************************************
		使用sizeof运算符测试出的结果会随着硬件以及操作系统的变化而变化
================================================================*/

#include <stdio.h>
#include <stdlib.h>
//任务 : 使用sizeof运算符,计算 char short int long float double 的字节数
int main(int argc, char *argv[])
{
	printf("sizeof(char) = %ld\n", sizeof(char));
	printf("sizeof(short) = %ld\n", sizeof(short));
	printf("sizeof(int) = %ld\n", sizeof(int));
	printf("sizeof(long) = %ld\n", sizeof(long));
	printf("sizeof(float) = %ld\n", sizeof(float));
	printf("sizeof(double) = %ld\n", sizeof(double));

	return 0;
}






