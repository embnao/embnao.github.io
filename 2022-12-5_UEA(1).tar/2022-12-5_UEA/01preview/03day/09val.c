#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	int year, month, day;//如果定义多个相同类型的变量,可以使用,隔开变量名
	int hour, min, sec;

	year = 2022;
	month = 12;
	day = 7;
	hour = 14;
	min = 50;
	sec = 0;

	printf("%d年%d月%d日\n", year, month, day);
	printf("%d:%d:%d\n", hour, min, sec);

	return 0;
}






