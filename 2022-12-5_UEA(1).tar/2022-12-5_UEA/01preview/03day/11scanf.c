/*================================================================
*   Copyright (C) 2022 Sangfor Ltd. All rights reserved.
*   
*   文件名称：11scanf.c
*   创 建 者：ZaCk
*   创建日期：2022年12月07日
*   创建时间：16时01分33秒
*   描    述：
*
================================================================*/

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	int year = 2022, month = 12, day = 7;

	printf("%d年%d月%d日\n", year, month, day);

	//scanf("%d-%d-%d", &year, &month, &day);
	//scanf("%d %d %d", &year, &month, &day);
	scanf("%d,%d,%d", &year, &month, &day);

	printf("%d年%d月%d日\n", year, month, day);

	return 0;
}










