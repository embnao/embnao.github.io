/*================================================================

================================================================*/
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	int a = 0, b = 0;
	int tmp = 0;//中间变量

	scanf("%d-%d", &a, &b);//通过scanf函数录入a变量和b变量的值
	// a = 13, b = 7
	printf("a = %d b = %d\n", a, b);
	//任务 : 通过某种方法交换a变量和b变量的值,完成之后在腾讯文档中标记

	tmp = a;//把a变量存储的数据备份到tmp变量中
	a = b;//把b变量存储的数据备份到a变量中
	b = tmp;//把tmp变量存储的数据备份到b变量中
	
	printf("a = %d b = %d\n", a, b);
	//注意 : printf("a = %d b = %d\n", b, a);

	return 0;
}






