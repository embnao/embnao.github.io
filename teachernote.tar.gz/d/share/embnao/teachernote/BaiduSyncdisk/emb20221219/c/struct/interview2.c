#include <stdio.h>

int main(void)
{
	int a;
	int *b;
	int **c;
	int d[5];
	int *e[10];
	int (*f)[5];
	int (*g)(int, char *);
	int (*h[10])(void);
	int (*(*i)[10])(void);


	return 0;
}

