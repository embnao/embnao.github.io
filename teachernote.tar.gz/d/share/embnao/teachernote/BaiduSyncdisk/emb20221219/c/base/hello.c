#include <stdio.h>

/*
   多行注释
#开头的---》预处理指令
#include 包含头文件

main使入口函数，必须要有的

return 0;整个进程运行成功

printf输出函数 "字符串"

c语言1971丹尼斯-李奇，改写UNIX
1972Unix完全用c改写
c标准c11
 */

int main(void)
{
	// 输出 单行注释
	printf("hello world\n");

	return 0;
}

