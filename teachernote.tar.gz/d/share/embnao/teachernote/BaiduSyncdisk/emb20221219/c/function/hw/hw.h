#ifndef __HW_H
#define __HW_H

extern int max3num(int a, int b, int c);

extern int op2num(int a, int b, char op);

extern int factorial_n(int n);

#endif

