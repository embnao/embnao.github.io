
// ADT
typedef struct {
	int token;
	int cps;
	int burst;
}token_t;

// 存储所有令牌桶
token_t *libs[TBFNR] = {};


